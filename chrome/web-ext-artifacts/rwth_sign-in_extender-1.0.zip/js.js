chrome.runtime.sendMessage({
  type: "setExpirationDate",
});

console.log("setExpirationDate");
